
public class Spieler {
    String name;
    int nummer;
    
    public String toString() {
        return name + " (" + nummer + ")";
    }
}
