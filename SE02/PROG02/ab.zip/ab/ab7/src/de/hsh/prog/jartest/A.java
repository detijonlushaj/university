package de.hsh.prog.jartest;
public class A {
    public static void main(String[] args) {
        B b= new B();
        System.out.println(b);
    }
}