
public class Main {

    public static void main(String[] args) {
        Bankkonto a = new Bankkonto();
        Bankkonto b = new Bankkonto();
        Bankkonto c = new Bankkonto();
        
        System.out.println(Bankkonto.getAnzahlKonto());
    }

}
