package de.hsh.prog.jartest;
public class B {
    public String toString() {
        return "This is B";
    }
}
